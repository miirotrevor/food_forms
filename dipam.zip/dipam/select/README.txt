A Pen created at CodePen.io. You can find this one at https://codepen.io/marki10/pen/WpRoWN.

 